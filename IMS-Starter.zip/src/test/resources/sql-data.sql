INSERT INTO `ims`.`customers` (`first_name`, `surname`) VALUES ('jordan', 'harrison');
INSERT INTO `ims`.`customers` (`first_name`, `surname`) VALUES ('rick', 'francis');
INSERT INTO `ims`.`customers` (`first_name`, `surname`) VALUES ('martina', 'green');

INSERT INTO `ims`.`items` (`name`, `value`) VALUES ('figurine', '10.00');
INSERT INTO `ims`.`items` (`name`, `value`) VALUES ('book', '5.00');
INSERT INTO `ims`.`items` (`name`, `value`) VALUES ('dice', '1.00');

INSERT INTO `ims`.`orders` (`customer_id`) VALUES ('1');
INSERT INTO `ims`.`orders` (`customer_id`) VALUES ('2');
INSERT INTO `ims`.`orders` (`customer_id`) VALUES ('3');

INSERT INTO `ims`.`order-items` (`order_id`, `item_id`) VALUES ('1', '1');
INSERT INTO `ims`.`order-items` (`order_id`, `item_id`) VALUES ('1', '2');
INSERT INTO `ims`.`order-items` (`order_id`, `item_id`) VALUES ('1', '3');