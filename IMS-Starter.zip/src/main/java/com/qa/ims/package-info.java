/**
 * This package is the parent of the ims project.
 */
package com.qa.ims;