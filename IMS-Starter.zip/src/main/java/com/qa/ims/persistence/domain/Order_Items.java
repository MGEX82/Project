package com.qa.ims.persistence.domain;

public class Order_Items {

}
