package com.qa.ims.persistence.domain;

public class Order_Item {
	private Long order_Id;
	private Long item_Id;
	

	public Order_Item(Long order_Id, Long item_Id) {
		this.setOrder_Id(order_Id);
		this.setItem_Id(item_Id);
	}

	
		
	


	

	public Long getOrder_Id() {
		return order_Id;
	}

	public void setOrder_Id(Long order_Id) {
		this.order_Id = order_Id;
	}

	public Long getItem_Id() {
		return item_Id;
	}

	public void setItem_Id(Long item_Id ) {
		this.item_Id = item_Id;
	}

	@Override
	public String toString() {
		return "Order ID:" + order_Id + "Item ID:" + item_Id;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((order_Id == null) ? 0 : order_Id.hashCode());
		result = prime * result + ((item_Id == null) ? 0 : item_Id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Order_Item other = (Order_Item) obj;
		if (getOrder_Id() == null) {
			if (other.getOrder_Id() != null)
				return false;
		} else if (!getOrder_Id().equals(other.getOrder_Id()))
			return false;
		if (item_Id == null) {
			if (other.item_Id != null)
				return false;
		} else if (!item_Id.equals(other.item_Id))
			return false;
		return false;		
	}

}
