/**
 * This package is used to take in a user inputs.
 */
package com.qa.ims.controller;