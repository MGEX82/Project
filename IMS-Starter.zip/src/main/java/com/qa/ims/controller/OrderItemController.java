package com.qa.ims.controller;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


import com.qa.ims.persistence.dao.OrderItemDAO;

import com.qa.ims.persistence.domain.OrderItem;
import com.qa.ims.utils.Utils;

/**
 * Takes in order item details for CRUD functionality
 *
 */
public class OrderItemController implements CrudController<OrderItem>  {
	public static final Logger LOGGER = LogManager.getLogger();

	private OrderItemDAO order_itemDAO;
	private Utils utils;

	public OrderItemController(OrderItemDAO order_itemDAO, Utils utils) {
		super();
		this.order_itemDAO = order_itemDAO;
		this.utils = utils;
	}

	/**
	 * Reads all order items to the logger
	 */
	@Override
	public List<OrderItem> readAll() {
		List<OrderItem> order_items = order_itemDAO.readAll();
		for (OrderItem order_item : order_items) {
			LOGGER.info(order_item);
		}
		return order_items;
	}

	/**
	 * Creates an order item by taking in user input
	 */
	@Override
	public OrderItem create() {
		LOGGER.info("Please enter an order ID");
		Long order_Id = utils.getLong();
		LOGGER.info("Please enter an item ID");
		Long item_Id = utils.getLong();
		OrderItem order_item = order_itemDAO.create(new OrderItem(order_Id, item_Id));
		LOGGER.info("Order item created");
		return order_item;
	}

	/**
	 * Updates an existing order item by taking in user input
	 */
	@Override
	public OrderItem update() {
		LOGGER.info("Please enter the order Id of the customer you would like to update");
		Long order_Id = utils.getLong();
		LOGGER.info("Please enter a item ID");
		Long item_Id = utils.getLong();
		OrderItem order_item = order_itemDAO.update(new OrderItem(order_Id, item_Id));
		LOGGER.info("Customer Updated");
		return order_item;
	}

	/**
	 * Deletes an existing order item by the id of the item
	 * 
	 * @return
	 */
	@Override
	public int delete() {
		LOGGER.info("Please enter the id of the item you would like to delete");
		Long item_Id = utils.getLong();
		return order_itemDAO.delete(item_Id);
	}
	

}
