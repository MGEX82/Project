/**
 * This package is used to provide utilities which can be reused through the application.
 */
package com.qa.ims.utils;